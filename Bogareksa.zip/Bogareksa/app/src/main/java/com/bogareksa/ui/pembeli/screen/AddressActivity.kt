package com.bogareksa.ui.pembeli.screen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bogareksa.R

class AddressActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_address)
    }
}