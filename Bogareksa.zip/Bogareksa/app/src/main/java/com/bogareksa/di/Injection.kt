package com.bogareksa.di

object Injection {



}