package com.bogareksa.ui.pembeli.screen

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun ProductList(
    modifier: Modifier = Modifier
){}